﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Net;
using System.IO;
using System.Web.Script.Serialization;
using Test.Models;

namespace Test.Controllers
{
    public class JsonOrganizerController : Controller
    {
        JavaScriptSerializer jsSerializer = new JavaScriptSerializer();

        //
        // GET: /JsonOrganizer/


        public ActionResult Index()
        {
            return View();
        }

        public String GetOrganizerList()
        {
            var queryString = HttpContext.Request.QueryString;
            var page = int.Parse(queryString.GetValues("pagenum")[0]);
            var size = int.Parse(queryString.GetValues("pagesize")[0]);
            var sort = queryString.GetValues("sortorder")[0];

            string paramaters = string.Format("page={0}&size={1}&sort={2}", page, size, sort);

            HttpWebRequest webRequest = WebRequest.Create("http://tester.t4.voxteneo.com/sport_events_voxteneo/api/organizers?" + paramaters) as HttpWebRequest;
            webRequest.Headers.Add(HttpRequestHeader.AcceptEncoding, "gzip, deflate");
            webRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

            HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();

            StreamReader streamReader = new StreamReader(webResponse.GetResponseStream());
            string apiResp = streamReader.ReadToEnd();

            List<Organizer> lsOrganizer = jsSerializer.Deserialize<List<Organizer>>(apiResp);

            string data = "{ \"count\": " + lsOrganizer.Count + ", \"data\":" + apiResp + "}";



            return data;
        }

    }
}
