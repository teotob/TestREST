﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Test.Models
{
    public class Organizer
    {
        public int? id { get; set; }
        public string organizerName { get; set; }
        public string imageLocation { get; set; }
    }
}